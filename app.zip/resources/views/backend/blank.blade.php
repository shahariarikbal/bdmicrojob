@extends('backend.master')

@section('title')
    Global Earn Money
@endsection

@section('page-css')
<style>
	
</style>
@endsection


@section('content')

{{-- container-fluid pb-0 here --}}


@endsection

@section('page-scripts')
<script type="text/javascript">
	
</script>
@endsection
