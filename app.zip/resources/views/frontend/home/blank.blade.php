@extends('frontend.master')

@section('contain')

{{-- enter main section here --}}

@endsection
