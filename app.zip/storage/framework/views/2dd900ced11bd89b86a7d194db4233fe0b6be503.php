<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid pb-0">














    <div class="video-block section-padding">
       <div class="row">
          <div class="col-xl-3 col-md-4 col-sm-6 mb-4">
            <div class="card radius-10" style="background: linear-gradient(131.26deg,#5E44C9 26.64%,#2448D6 214.9%)">
                <div class="card-body text-center">
                    <p class="mb-1 text-white" style="font-size: 17px;font-weight: 600;">Approved Jobs</p>
                    <h3 class="text-white">
                        <?php echo e($approved_job_count); ?>

                    </h3>
                </div>
            </div>
             <!-- <div class="custom-card-one">
                <div class="row">
                   <div class="col-md-4">
                    <img src="<?php echo e(asset('backend/')); ?>/img/Vector.png" style="height: 50px; margin-top: 25px; margin-left: 15px;"/>
                   </div>
                   <div class="col-md-8">
                    <p class="earn-box-one">Approved Jobs</p>
                    <p class="earn-box-one"><?php echo e($approved_job_count); ?></p>
                   </div>
               </div>
             </div> -->
          </div>
          <div class="col-xl-3 col-md-4 col-sm-6 mb-4">
            <div class="card radius-10" style="background: linear-gradient(131.26deg,#5E44C9 26.64%,#2448D6 214.9%)">
                <div class="card-body text-center">
                    <p class="mb-1 text-white" style="font-size: 17px;font-weight: 600;">Pending Jobs</p>
                    <h3 class="text-white">
                        <?php echo e($pending_job_count); ?>

                    </h3>
                </div>
            </div>
          </div>
          <div class="col-xl-3 col-md-4 col-sm-6 mb-4">
            <div class="card radius-10" style="background: linear-gradient(131.26deg,#5E44C9 26.64%,#2448D6 214.9%)">
                <div class="card-body text-center">
                    <p class="mb-1 text-white" style="font-size: 17px;font-weight: 600;">Total users</p>
                    <h3 class="text-white">
                        <?php echo e($user_count); ?>

                    </h3>
                </div>
            </div>
          </div>
       </div>
    </div>

    <div class="card">
        <div class="card-header">
            <span style="font-size: 18px; font-weight: bold">Visitor's List</span>
        </div>
        <div class="card-body">
            <div class="col-md-10 m-auto">
                <form method="GET" action="<?php echo e(url('/admin/dashboard')); ?>" class="gobal-serch-form form-group mb-3">
                    <?php echo csrf_field(); ?>
                    <div class="row" style="width: 100%">
                        <div class="col-md-5 mb-2">
                            <div class="d-flex align-items-center">
                                <span class="input-group-text bg-gradient-blues" style="background-color: black; color: white">From</span>
                                <input type="date" class="form-control" name="from" placeholder="From date" aria-label="Username" style="padding: 18px;">
                            </div>
                        </div>
                        <div class="col-md-5 mb-2">
                            <div class="d-flex align-items-center">
                                <span class="input-group-text bg-gradient-burning" style="background-color: black; color: white">To</span>
                                <input type="date" class="form-control" name="to" placeholder="To date" aria-label="Server" style="padding: 18px;">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="d-flex align-items-center">
                                <button type="submit" class="input-group-text text-white btn btn-primary" style="margin-right: 5px">Search</button>
                                <a href="<?php echo e(url('/admin/dashboard')); ?>" class="input-group-text text-white btn btn-danger">Clear</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <table class="table table-hover table-bordered">
                <tr>
                    <th>SL</th>
                    <th>Visit Date</th>
                    <th>IP</th>
                    <th>Browser</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e(date('d-M-Y', strtotime($visitor->created_at))); ?></td>
                        <td>
                            <a href="<?php echo e(url('/admin/visitor/view/'.$visitor->id)); ?>"><?php echo e($visitor->ip); ?></a>
                        </td>
                        <td><?php echo e($visitor->browser); ?></td>
                        <td>
                            <a href="<?php echo e(url('/admin/visitor/view/'.$visitor->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-eye"></i>
                            </a>



                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php echo e($visitors->links()); ?>

        </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>