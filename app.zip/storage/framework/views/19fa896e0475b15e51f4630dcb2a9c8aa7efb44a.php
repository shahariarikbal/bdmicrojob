
        <link href="<?php echo e(asset('backend')); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />

        <link href="<?php echo e(asset('backend')); ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend')); ?>/css/osahan.css" rel="stylesheet" />

        <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendor/owl-carousel/owl.carousel.css" />
        <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendor/owl-carousel/owl.theme.css" />

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <!-- Summernote CSS - CDN Link -->
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
        <!-- //Summernote CSS - CDN Link -->


<?php /**PATH C:\laragon\www\bdmicrojob\resources\views/backend/includes/css.blade.php ENDPATH**/ ?>