

<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid pb-0">
    <div class="top-mobile-search">
       <div class="row">
          <div class="col-md-12">
             <form class="mobile-search">
                <div class="input-group">
                   <input type="text" placeholder="Search for..." class="form-control">
                   <div class="input-group-append">
                      <button type="button" class="btn btn-dark"><i class="fas fa-search"></i></button>
                   </div>
                </div>
             </form>
          </div>
       </div>
    </div>
    <div class="video-block section-padding">
       <div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
             <div class="custom-card-one">
                <div class="row">
                   <div class="col-md-4">
                    <img src="<?php echo e(asset('backend/')); ?>/img/Vector.png" style="height: 50px; margin-top: 25px; margin-left: 15px;"/>
                   </div>
                   <div class="col-md-8">
                    <p class="earn-box-one">Subscription total amounts</p>
                   </div>
               </div>
             </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
             <div class="custom-card-two">
                <div class="row">
                   <div class="col-md-4">
                      <div style="border: 2px solid #ffffff; height: 40px; margin-top: 25px; margin-left: 15px; border-radius: 8px; width: 50px;">
                         <img src="<?php echo e(asset('backend/')); ?>/img/Vector1.png" style="height: 20px; margin-top: 8px; margin-left: 15px;"/>
                      </div>
                   </div>
                   <div class="col-md-8">
                    <p class="earn-box-one">Total videos</p>
                   </div>
               </div>
             </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
             <div class="custom-card-three">
                <div class="row">
                   <div class="col-md-4">
                    <img src="<?php echo e(asset('backend/')); ?>/img/Vector2.png" style="height: 50px; margin-top: 25px; margin-left: 15px;"/>
                   </div>
                   <div class="col-md-8">
                    <p class="earn-box-one">Share Links And Get Rewards !</p>
                   </div>
               </div>
             </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
             <div class="custom-card-four">
                <div class="row">
                   <div class="col-md-4">
                    <img src="<?php echo e(asset('backend/')); ?>/img/Vector3.png" style="height: 50px; margin-top: 25px; margin-left: 15px;"/>
                   </div>
                   <div class="col-md-8">
                    <p class="earn-box-one">Total users list</p>
                   </div>
               </div>
             </div>
          </div>
       </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tererded24\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>