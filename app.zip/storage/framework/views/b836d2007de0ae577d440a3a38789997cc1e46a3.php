<nav class="navbar-expand navbar-light bg-white static-top osahan-nav sticky-top">
    <div class="user-navbar-items-wrap">
        <div class="header-left-side">
            <button class="btn btn-link btn-sm text-secondary order-1 order-sm-0" id="sidebarToggle">
               <i class="fas fa-bars"></i>
            </button>
            <a class="navbar-brand mr-1" href="#">
                <img src="<?php echo e(asset('/frontend/')); ?>/assets/logo/bd jobs.png" />
            </a>
        </div>
        <div class="text-center earning-btn-outer">
            <h4 class="user-dashb-earning-btn">Earning: <?php echo e($total_income->total_income); ?>tk</h4>
            <h4 class="user-dashb-deposit-btn">Deposit: <?php echo e($total_deposit->total_deposit); ?>tk</h4>
        </div>
        <ul class="navbar-nav ml-auto ml-md-0 osahan-right-navbar">
            
            <li class="nav-item dropdown no-arrow mx-1">
                <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <span class="badge badge-danger"><?php echo e($user_notification_count); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
                    <?php $__currentLoopData = $user_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user_notification->notifiable_type=='App\Models\NidVerification'): ?>
                    <a class="dropdown-item" href="<?php echo e(url('/nid_notification_seen/'.$user_notification->id)); ?>"><i class="fas fa-fw fa-star "></i> &nbsp; <?php echo e($user_notification->message); ?></a>
                    <?php elseif($user_notification->notifiable_type=='App\Models\Deposit'): ?>
                    <a class="dropdown-item" href="<?php echo e(url('/deposit_notification_seen/'.$user_notification->id)); ?>"><i class="fas fa-fw fa-star "></i> &nbsp; <?php echo e($user_notification->message); ?></a>
                    <?php elseif($user_notification->notifiable_type=='App\Models\Withdraw'): ?>
                    <a class="dropdown-item" href="<?php echo e(url('/withdraw_notification_seen/'.$user_notification->id)); ?>"><i class="fas fa-fw fa-star "></i> &nbsp; <?php echo e($user_notification->message); ?></a>
                    <?php elseif($user_notification->notifiable_type=='App\Models\Tip'): ?>
                    <a class="dropdown-item" href="<?php echo e(url('/tip_notification_seen/'.$user_notification->id)); ?>"><i class="fas fa-fw fa-star "></i> &nbsp; <?php echo e($user_notification->message); ?></a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </li>
            
            <li class="nav-item dropdown no-arrow osahan-right-navbar-user">
                <a class="nav-link dropdown-toggle user-dropdown-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php
                        $user = Auth::user();
                    ?>
                    <?php if(auth()->user()->avatar != null): ?>
                    <img alt="Avatar" src="<?php echo e(asset('/user/'.$user->avatar)); ?>" />
                    <?php else: ?>
                    <img alt="Avatar" src="<?php echo e(asset('backend')); ?>/img/user-avater.png" />
                    <?php endif; ?>
                    <?php echo e(auth()->user()->name); ?>

                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="<?php echo e(url('/profile/update')); ?>"><i class="fas fa-fw fa-user-circle"></i> &nbsp; My Account</a>
                    
                    
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal"><i class="fas fa-fw fa-sign-out-alt"></i> &nbsp; Logout</a>

                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\laragon\www\bdmicrojob\resources\views/frontend/auth/includes/nav.blade.php ENDPATH**/ ?>