

<?php $__env->startSection('contain'); ?>
<main>
    <section class="home-banner-section-wrapper">
        <div class="home-banner-image-outer">
            <img src="<?php echo e(asset('/homepage/'.$homepage->slider_image)); ?>">
        </div>
        <div class="home-banner-content">
            <h2 class="banner-content" style="color:blue">
                
                <?php echo e($homepage->slider_title); ?>

            </h2>
        </div>
    </section>
    
    <section class="extra-earning-section-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="left-image-outer">
                        <img src="<?php echo e(asset('/homepage/'.$homepage->first_image)); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="section-right-content">
                        <h3 class="right-content-title">
                            
                            <span><?php echo e($homepage->first_image_title); ?></span>
                        </h3>
                        <?php echo $homepage->first_image_description; ?>

                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    <section class="feature-section-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="section-left-content">
                        <h3 class="left-content-title">
                            
                            <span class="extra-color"><?php echo e($homepage->second_image_title); ?></span>
                        </h3>
                        <ul class="feature-section-list">
                            <?php echo $homepage->second_image_description; ?>

                            
                        </ul>
                    </div>
                    
                </div>
                <div class="col-md-6">
                    <div class="right-image-outer">
                        <img src="<?php echo e(asset('/homepage/'.$homepage->second_image)); ?>">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="recent-activitis-section">
        <div class="container">
            <div class="section-title-outer">
                <h5 class="subtitle">
                    BDMicrojob
                </h5>
                <h1 class="title">
                    Recent Activity
                </h1>
            </div>
            <div class="recent-activity-items-wrapper">
                <?php $__currentLoopData = $job_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $worker = \App\Models\PostSubmit::where('post_id', $job_post->id)->where('status', '!=' ,'2')->get()->count();
                ?>
                <?php if($worker < $job_post->worker_number): ?>
                <a href="<?php echo e(url('/dashboard')); ?>" class="recent-activity-item-outer">
                    <div class="text-right text-blue">Posted Date: <?php echo e(date('m-d-Y', strtotime($job_post->created_at))); ?></div>
                    <div class="item-title">
                        <span><?php echo e($job_post->title); ?> </span>
                    </div>
                    <div class="item-content">
                        <div class="item-left-content">
                            <span>
                                <?php echo e($job_post->user->name); ?>

                            </span>
                        </div>
                        <div class="item-center-content">
                            <div class="progress-label">
                                <?php echo e($worker); ?> OF <?php echo e($job_post->worker_number); ?>

                            </div>
                            <div class="progress">
                                <?php if($worker >= 100): ?>
                                <div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="<?php echo e($worker); ?>" aria-valuemin="0" aria-valuemax="<?php echo e($job_post->worker_number); ?>"></div>
                                <?php else: ?>
                                <div class="progress-bar" role="progressbar" style="width: <?php echo e($worker); ?>%" aria-valuenow="<?php echo e($worker); ?>" aria-valuemin="0" aria-valuemax="<?php echo e($job_post->worker_number); ?>"></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="item-right-content">
                            <div class="totla-earning">
                                BDT <b><?php echo e($job_post->category->worker_earning); ?></b>
                            </div>
                        </div>
                    </div>
                </a>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </section>
    <section class="video-section-wrapper">
        <div class="container">
            <div class="col-md-8 m-auto">
                <div class="video-section-top-content">
                    <h3 class="video-section-top-title">
                        
                        <span><?php echo e($homepage->how_works_title); ?></span>
                    </h3>
                    <div class="video-section-top-des-outer">
                        
                            <?php echo $homepage->how_works_description; ?>

                        
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="video-section-outer">
            <div class="video-section-image-outer">
                <img src="<?php echo e(asset('/homepage/'.$homepage->footer_image)); ?>">
            </div>
            <div class="video-icon-outer">
                <i class="fas fa-play-circle"></i>
            </div>
        </div>
    </section>
    <section class="signup-now-section-wrapper">
        <div class="container">
            <div class="col-md-8 m-auto">
                <h3 class="signup-now-section-title">
                    
                    <span class="extra-color"><?php echo e($homepage->footer_title); ?></span>
                </h3>
                <p class="signup-now-section-des">
                    <?php echo $homepage->footer_description; ?>

                </p>
                <div class="section-btn-outer">
                    <button type="button" class="section-btn-inner">
                        Go To The Dashboard
                    </button>
                </div>
            </div>
        </div>
    </section>
    <section class="counter-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="counter-item-outer">
                        <h4 class="counter-title">Page Views</h4>
                        <h3 class="counter-number"><?php echo e($visitorCount ?? 0); ?></h3>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="counter-item-outer">
                        <h4 class="counter-title">Total Users</h4>
                        <h3 class="counter-number"><?php echo e($userCount ?? 0); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>