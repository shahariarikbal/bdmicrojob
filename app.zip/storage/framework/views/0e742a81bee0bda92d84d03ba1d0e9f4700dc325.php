

<?php $__env->startSection('title'); ?>
    Membership list
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
<style type="text/css">
    th{
        text-transform: capitalize;
    }
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-0">
        <div class="card">
            <div class="card-header">
            	<div class="row">
            		<div class="col-md-6">
                		<h2>Advertisement list</h2>
            		</div>
            		
            	</div>

            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <h1>Advertisements....</h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/backend/advertisement/show-advertisements.blade.php ENDPATH**/ ?>