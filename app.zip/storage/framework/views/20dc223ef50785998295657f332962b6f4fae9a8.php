

<?php $__env->startSection('title'); ?>
    Pending Job list
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
<style type="text/css">
    th{
        text-transform: capitalize;
    }
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-0">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-6">
                        <h2>Pending Job list</h2>
                    </div>                    
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <div class="table-responsive-scroll">
                        <table class="table table-striped">
                            <thead>
                              <tr>
                                <th scope="col" class="sort">SL</th>
                                <th scope="col" class="sort">Catrgory Name</th>
                                <th scope="col" class="sort">Title</th>
                                <th scope="col" class="sort">Total Worker</th>
                                <th scope="col" class="sort">Per job Earn</th>
                                <th scope="col" class="sort">Status</th>
                                <th scope="col" class="sort">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pending_job_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending_job_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="my-task-valued">
                                    <td>
                                        <h6 class="task-name-text">
                                            <?php echo e($loop->index+1); ?>

                                        </h6>
                                    </td>
                                    <td>
                                        <h6 class="task-earned-text">
                                            <?php echo e($pending_job_post->category->name ?? 'No name found'); ?>

                                        </h6>
                                    </td>
                                    <td>
                                        <?php echo e($pending_job_post->title); ?>

                                    </td>
                                    <td>
                                        <h6 class="task-date-text">
                                            <?php echo e($pending_job_post->worker_number); ?>

                                        </h6>
                                    </td>
                                    <td>
                                        <h6 class="task-date-text">
                                            <?php echo e($pending_job_post->category->worker_earning); ?>tk
                                        </h6>
                                    </td>
                                    <td>
                                        <h6 class="task-date-text">
                                            <?php if($pending_job_post->is_approved==1): ?>
                                                Approved
                                            <?php elseif($pending_job_post->is_approved==2): ?>
                                                Rejected
                                            <?php else: ?>
                                                Pending
                                            <?php endif; ?>
                                        </h6>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('/admin/job/details/'.$pending_job_post->id)); ?>" class="btn btn-sm btn-info">Details</a>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($pending_job_posts->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/backend/job/show-pending-jobs.blade.php ENDPATH**/ ?>