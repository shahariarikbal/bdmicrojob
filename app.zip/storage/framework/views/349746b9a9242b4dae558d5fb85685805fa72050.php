

<?php $__env->startSection('title'); ?>
    Give Tips
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
    <style>
    	h2,label{
    		text-transform: capitalize;
    	}
    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-0">
        <div class="card">
            <div class="card-header">
            	<div class="row">
            		<div class="col-md-6">
                		<h2>Give Tips</h2>
            		</div>
                    <div class="col-md-6 text-right">
                        <a href="<?php echo e(url('/admin/users')); ?>" class="btn btn-primary">Back</a>
                    </div>
            	</div>
            </div>
            <div class="card-body">
                <div class="col-md-12">
                	<form action="<?php echo e(url('admin/tip/store/'.$user->id)); ?>" method="post">
                		<?php echo csrf_field(); ?>

                		<div class="form-group">
                            <label for="user_name">User Name</label>
                            <input type="text" name="user_name" value="<?php echo e($user->name); ?>" class="form-control" readonly>
                            <?php if($errors->has('user_name')): ?>
                            <div class="text-danger"><?php echo e($errors->first('user_name')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="user_email">User Email</label>
                            <input type="email" name="user_email" value="<?php echo e($user->email); ?>" class="form-control" readonly>
                            <?php if($errors->has('user_email')): ?>
                            <div class="text-danger"><?php echo e($errors->first('user_email')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="tips_type">Tips Type</label>
                            <select name="tips_type" value="<?php echo e(old('tips_type')); ?>" class="deposit-form-input form-control">
                                <option selected disabled>-- Select Tips Type --</option>
                                <option value="earning">Earning</option>
                                <option value="deposit">Deposit</option>
                            </select>
                            <?php if($errors->has('tips_type')): ?>
                            <div class="text-danger"><?php echo e($errors->first('tips_type')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="tips_amount">Tips Amount</label>
                            <input type="text" name="tips_amount" value="<?php echo e(old('tips_amount')); ?>" class="form-control">
                            <?php if($errors->has('tips_amount')): ?>
                            <div class="text-danger"><?php echo e($errors->first('tips_amount')); ?></div>
                            <?php endif; ?>
                        </div>
                		<button type="submit" class="btn btn-success mt-3">Submit</button>
                	</form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/backend/tip/show-tip-page.blade.php ENDPATH**/ ?>