

<?php $__env->startSection('title'); ?>
	My Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="my-task-section">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header border-0">
                    <h3 class="mb-0" style="font-size: 20px;color: #7E41C2">My Post</h3>
                </div>
                <!-- Light table -->
                <div class="table-responsive active">
                    <table class="table align-items-center table-striped table-hover table-flush my-task-table">
                        <thead class="thead-light my-task-th">
                            <tr class="my-task-th-outer">
                                <th scope="col" class="sort">SL</th>
                                <th scope="col" class="sort">Catrgory Name</th>
                                <th scope="col" class="sort">Title</th>
                                <th scope="col" class="sort">Total Worker</th>
                                <th scope="col" class="sort">Per job Earn</th>
                                <th scope="col" class="sort">Status</th>
                                <th scope="col" class="sort">Action</th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="my-task-valued">
                                    <td>
                                        <h6 class="task-name-text">
                                            <?php echo e($loop->index+1); ?>

                                        </h6>
                                    </td>
                                    <td>
                                        <h6 class="task-earned-text">
                                            <?php echo e($post->category->name ?? 'No name found'); ?>

                                        </h6>
                                    </td>
                                    <td>
                                        <?php echo e($post->title); ?>

                                    </td>
                                    <td>
                                        <h6 class="task-date-text">
                                            <?php echo e($post->worker_number); ?>

                                        </h6>
                                    </td>
                                    <td>
                                        <h6 class="task-date-text">
                                            <?php echo e($post->category->worker_earning); ?>

                                        </h6>
                                    </td>
                                    <td>
                                        <h6 class="task-date-text">
                                            <?php if($post->is_approved==1): ?>
                                                Approved
                                            <?php elseif($post->is_approved==2): ?>
                                                Rejected
                                            <?php else: ?>
                                                Pending
                                            <?php endif; ?>
                                        </h6>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('/post/add-worker/'.$post->id)); ?>" class="btn btn-sm btn-warning">Add Worker</a>
                                        
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/frontend/auth/user/my-post.blade.php ENDPATH**/ ?>