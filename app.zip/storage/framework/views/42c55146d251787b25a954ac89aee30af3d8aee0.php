<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $setting->adsense_code; ?>

        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Askbootstrap" />
        <meta name="author" content="Askbootstrap" />
        <?php echo $__env->yieldPushContent('meta'); ?>
        <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

        <link rel="icon" type="image/png" href="<?php echo e(asset('backend')); ?>/img/favicon.png" />

        <?php echo $__env->make('frontend.auth.includes.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldPushContent('page-css'); ?>
    </head>
    <body id="page-top">


        <?php echo $__env->make('frontend.auth.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




		<div id="wrapper">


        	<?php echo $__env->make('frontend.auth.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div id="content-wrapper">

	        	<?php echo $__env->yieldContent('content'); ?>

	        	<?php echo $__env->make('frontend.auth.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
		</div>




        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>





        <?php echo $__env->make('frontend.auth.includes.logout-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <?php echo $__env->make('frontend.auth.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldPushContent('page-scripts'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\bdmicrojob\resources\views/frontend/auth/master.blade.php ENDPATH**/ ?>