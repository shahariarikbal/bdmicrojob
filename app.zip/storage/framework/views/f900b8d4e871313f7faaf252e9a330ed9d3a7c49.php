<ul class="sidebar navbar-nav<?php echo e(Route::is('dashboard') ? 'toggled' : ''); ?>">
    <li class="nav-item <?php echo e(Request::url() == url('admin/dashboard') ? 'active' : ''); ?>">
       <a class="nav-link" href="<?php echo e(url('/admin/dashboard')); ?>">
       <i class="fas fa-fw fa-home"></i>
       <span>Home</span>
       </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/link') ? 'active' : ''); ?> ">
       <a class="nav-link" href="<?php echo e(url('/admin/users')); ?>">
          <i class="fas fa-solid fa-dollar-sign"></i>
       <span>Users</span>
       </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/video/index') ? 'active' : ''); ?>">
       <a class="nav-link" href="<?php echo e(url('/admin/video/index')); ?>">
          <i class="fab fa-youtube"></i>
       <span>Videos</span>
       </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/link') ? 'active' : ''); ?>">
       <a class="nav-link" href="<?php echo e(url('/admin/membership/index')); ?>">
          <i class="fas fa-qrcode"></i>
       <span>Memberships</span>
       </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/link') ? 'active' : ''); ?>">
       <a class="nav-link" href="<?php echo e(url('/admin/withdraw/request')); ?>">
        <i class="fas fa-money-bill"></i>
       <span>Payments request</span>
       </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/link') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/settings')); ?>">
         <i class="fas fa-cog"></i>
        <span>Settings</span>
        </a>
     </li>
 </ul>
<?php /**PATH C:\laragon\www\Tererded24\resources\views/backend/includes/sidebar.blade.php ENDPATH**/ ?>