<?php $__env->startSection('title'); ?>
    Deposit list
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-0">
        <div class="card">
            <div class="card-header">
            	<div class="row">
            		<div class="col-md-6">
                		<h2>Deposit list</h2>
            		</div>
            	</div>
            </div>
            <div class="card-body">
                <div class="col-md-10 m-auto">
                    <form method="GET" action="<?php echo e(url('/admin/deposit/request')); ?>" class="gobal-serch-form form-group mb-3">
                        <?php echo csrf_field(); ?>
                        <div class="row" style="width: 100%">
                            <div class="col-md-5 mb-2">
                                <div class="d-flex align-items-center">
                                    <span class="input-group-text bg-gradient-blues" style="background-color: black; color: white">From</span>
                                    <input type="date" class="form-control" name="from" placeholder="From date" aria-label="Username" style="padding: 18px;">
                                </div>
                            </div>
                            <div class="col-md-5 mb-2">
                                <div class="d-flex align-items-center">
                                    <span class="input-group-text bg-gradient-burning" style="background-color: black; color: white">To</span>
                                    <input type="date" class="form-control" name="to" placeholder="To date" aria-label="Server" style="padding: 18px;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="d-flex align-items-center">
                                    <button type="submit" class="input-group-text text-white btn btn-primary" style="margin-right: 5px">Search</button>
                                    <a href="<?php echo e(url('/admin/deposit/request')); ?>" class="input-group-text text-white btn btn-danger">Clear</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-12">
                    <div class="table-responsive-scroll">
                        <table class="table table-striped">
                            <thead>
                              <tr>
                                <th scope="col">#</th>
                                <th scope="col">User Name</th>
                                <th scope="col">User Email</th>
                                <th scope="col">User Phone</th>
                                <th scope="col">Deposit Amount</th>
                                <th scope="col">Payment System</th>
                                <th scope="col">Transaction ID</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($deposit->user_name); ?></td>
                                    <td><?php echo e($deposit->user_email); ?></td>
                                    <td><?php echo e($deposit->user_phone); ?></td>
                                    <td><?php echo e($deposit->deposit_amount); ?>tk</td>
                                    <td><?php echo e($deposit->payment_gateway); ?></td>
                                    <td><?php echo e($deposit->transaction_id); ?></td>
                                    <td>
                                        <?php if($deposit->is_approved == '1'): ?>
                                        <a href="#" class="btn btn-sm btn-success">Approved</a>
                                        <?php elseif($deposit->is_approved == '2'): ?>
                                        <a href="#" class="btn btn-sm btn-danger">Rejected</a>
                                        <?php else: ?>
                                        <a href="#" class="btn btn-sm btn-warning">Pending</a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($deposit->is_approved == '0'): ?>
                                        <a href="<?php echo e(url('admin/deposit/approve/'.$deposit->id)); ?>" onclick="return confirm('Are you sure??')" class="btn btn-sm btn-danger">Approve</a>
                                        <a href="<?php echo e(url('admin/deposit/reject/'.$deposit->id)); ?>" onclick="return confirm('Are you sure??')" class="btn btn-sm btn-primary">Reject</a>
                                        <?php elseif($deposit->is_approved == '1'): ?>
                                        <a href="#" class="btn btn-sm btn-success">Approved</a>
                                        <?php elseif($deposit->is_approved == '2'): ?>
                                        <a href="#" class="btn btn-sm btn-danger">Rejected</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($deposits->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/backend/payment/show-deposit.blade.php ENDPATH**/ ?>