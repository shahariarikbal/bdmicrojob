<!-- Bootstrap link -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<!-- google Fonts Link -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,800;1,900&display=swap" rel="stylesheet">
<!-- Fontawesome Link -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/frontend/')); ?>/assets/font/fontawesome/css/all.css">
<!-- owl-cerousel css link -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/frontend/')); ?>/assets/plugins/owl-carousel/owl.carousel.min.css">




<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />


<!-- Main css Link -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/frontend/')); ?>/assets/css/style.css">
<?php /**PATH C:\laragon\www\Tererded24\resources\views/frontend/includes/style.blade.php ENDPATH**/ ?>