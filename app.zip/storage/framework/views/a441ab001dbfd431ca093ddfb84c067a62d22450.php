

        <link href="<?php echo e(asset('backend')); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />

        <link href="<?php echo e(asset('backend')); ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css" />

        <link href="<?php echo e(asset('backend')); ?>/css/osahan.css" rel="stylesheet" />

        <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendor/owl-carousel/owl.carousel.css" />
        <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendor/owl-carousel/owl.theme.css" />
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php /**PATH C:\laragon\www\bdmicrojob\resources\views/frontend/auth/includes/css.blade.php ENDPATH**/ ?>