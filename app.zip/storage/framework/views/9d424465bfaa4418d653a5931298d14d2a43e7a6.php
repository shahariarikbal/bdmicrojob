

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<title>Registration Form</title>
    <style>
        .login-sec-left-wave{
            position: fixed;
            bottom: 0;
            left: 0;
            height: 100%;
            z-index: -1;
        }

        .login-content-wrapper{
            width: 100vw;
            height: 100vh;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-gap :7rem;
            padding: 0 2rem;
        }

        .login-contant-left{
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }

        .login-content-right{
            display: flex;
            justify-content: flex-start;
            align-items: center;
            text-align: center;
        }

        .login-contant-left img{
            width: 500px;
        }

        .login-form{
            width: 100%;
            max-width: 360px;
            padding: 20px 0;
        }

        .login-content-right img{
            height: 100px;
        }

        .login-content-right h2{
            margin: 15px 0;
            color: #333;
            text-transform: uppercase;
            font-size: 2.9rem;
        }

        .login-content-right .login-form-outer{
            position: relative;
            display: grid;
            grid-template-columns: 7% 93%;
            margin: 25px 0;
            padding: 5px 0;
            border-bottom: 2px solid #d9d9d9;
        }


        .login-form-outer .icon{
            color: #d9d9d9;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-form-outer .icon i{
            transition: .3s;
        }

        .login-form-outer > div{
            position: relative;
            height: 45px;
        }

        .login-form-outer > div > h5{
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 18px;
            transition: .3s;
        }

        .login-form-outer:before, .login-form-outer:after{
            content: '';
            position: absolute;
            bottom: -2px;
            width: 0%;
            height: 2px;
            background-color: #7e41c2;
            transition: .4s;
        }

        .login-form-outer:before{
            right: 50%;
        }

        .login-form-outer:after{
            left: 50%;
        }

        .login-form-outer.focus:before, .login-form-outer.focus:after{
            width: 50%;
        }

        .login-form-outer.focus > div > h5{
            top: -5px;
            font-size: 15px;
        }

        .login-form-outer.focus > .login-form-outer .icon > i{
            color: #38d39f;
        }

        .login-form-outer .login-form-input input{
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            border: none;
            outline: none;
            background: none;
            padding: 0.5rem 0.7rem;
            font-size: 1.2rem;
            color: #555;
            font-family: 'poppins', sans-serif;
        }

        .forgot-pass-link{
            display: block;
            text-align: right;
            text-decoration: none;
            color: #999;
            font-size: 0.9rem;
            transition: .3s;
        }

        .forgot-pass-link:hover{
            color: #38d39f;
        }

        .login-form-submit{
            display: block;
            width: 100%;
            height: 50px;
            border-radius: 25px;
            outline: none;
            border: none;
            background: #7E41C2;
            background-size: 200%;
            font-size: 1.2rem;
            color: #fff;
            font-family: 'Poppins', sans-serif;
            text-transform: uppercase;
            margin: 1rem 0;
            cursor: pointer;
            transition: .5s;
        }
        .login-form-submit:hover{
            color: #fff;
        }

        .sign-in-link {
            text-decoration: none;
            font-size: 18px;
            font-weight: 600;
            color: #fff;
            background: #9a9a9a;
            padding: 5px 20px;
            border-radius: 30px;
            transition: all .3s ease;
        }
        .sign-in-link:hover {
            background: #7e3bc9c2;
            color: #fff;
        }
        .login-section {
            overflow-x: hidden;
        }

        @media  screen and (max-width: 1050px){
            .container{
                grid-gap: 5rem;
            }
        }

        @media  screen and (max-width: 1000px){
            .login-content-right h2{
                font-size: 2.4rem;
                margin: 8px 0;
            }

            .login-contant-left img{
                width: 400px;
            }
        }

        @media  screen and (max-width: 900px){
            .login-content-wrapper{
                grid-template-columns: 1fr;
            }

            .login-contant-left{
                display: none;
            }

            .login-sec-left-wave{
                display: none;
            }

            .login-content-right{
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<section class="login-section">
    <img class="login-sec-left-wave" src="https://raw.githubusercontent.com/sefyudem/Responsive-Login-Form/master/img/wave.png">
    <div class="login-content-wrapper">
        <div class="login-contant-left">
            <img src="https://raw.githubusercontent.com/sefyudem/Responsive-Login-Form/master/img/bg.svg">
        </div>
        <div class="login-content-right">
            <form action="<?php echo e(url('user/register')); ?>" method="POST" class="form-group login-form">
                <?php echo csrf_field(); ?>
                <img src="<?php echo e(asset('/logo/'.$setting->logo)); ?>" />
                <h2 class="title">Registration</h2>
                <div class="login-form-outer">
                    <div class="icon">
                      <i class="fas fa-user"></i>
                    </div>
                    <div class="login-form-input">
                      <h5>Name</h5>
                      <input id="name" type="text" name="name" class="input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <h6 class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </h6>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="login-form-outer">
                    <div class="icon">
                      <i class="fas fa-envelope"></i>
                    </div>
                    <div class="login-form-input">
                      <h5>Email</h5>
                      <input id="email" type="email" name="email" class="input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <h6 class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </h6>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>                    
                </div>
                <div class="login-form-outer">
                    <div class="icon">
                      <i class="fas fa-phone-alt"></i>
                    </div>
                    <div class="login-form-input">
                        <h5>Phone</h5>
                        <input id="phone" type="number" name="phone" class="input <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>" required autocomplete="phone" autofocus>
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <h6 class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </h6>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>                
                <div class="login-form-outer">
                    <div class="icon"> 
                        <i class="fas fa-lock"></i>
                    </div>
                    <div class="login-form-input">
                      <h5>Password</h5>
                      <input id="password" type="password" name="password" class="input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="new-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <h6 class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </h6>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="login-form-outer">
                    <div class="icon"> 
                        <i class="fas fa-lock"></i>
                    </div>
                    <div class="login-form-input">
                      <h5>Confirm Password</h5>
                      <input type="password" name="password_confirmation" class="input" required autocomplete="new-password">
                    </div>
                </div>
                <!-- <div class="login-form-outer">
                    <div class="icon">
                        <i class="fas fa-image"></i>
                    </div>
                    <div class="login-form-input">
                      <h5>Image</h5>
                      <input type="file" name="avater" class="input" required>
                    </div>
                </div> -->
                <button type="submit" class="login-form-submit">Registration</button>
                <a href="<?php echo e(route('login')); ?>" class="sign-in-link">Log In</a>
            </form>            
        </div>
    </div> 
</section>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<script>
    const inputs = document.querySelectorAll(".input");
    function addcl(){
        let parent = this.parentNode.parentNode;
        parent.classList.add("focus");
    }
    function remcl(){
        let parent = this.parentNode.parentNode;
        if(this.value == ""){
            parent.classList.remove("focus");
        }
    }
    inputs.forEach(input => {
        input.addEventListener("focus", addcl);
        input.addEventListener("blur", remcl);
    });

</script>
</body>
</html><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/auth/register.blade.php ENDPATH**/ ?>