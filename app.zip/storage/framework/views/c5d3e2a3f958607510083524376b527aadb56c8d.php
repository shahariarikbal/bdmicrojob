<?php $__env->startSection('title'); ?>
    User list
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-0">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-4">
                        <h4>Members list</h4>
                    </div>
                    <div class="col-md-8">
                        <form action="<?php echo e(url('/admin/users')); ?>" method="get">
                            <div class="row">
                                <div class="col-md-7">
                                    <input type="email" name="email" class="form-control" placeholder="Email" style="height: 40px;margin-bottom: 10px;">
                                </div>
                                <div class="col-md-5">
                                    <div class="input-group">
                                        <button type="submit" class="input-group-text text-white btn btn-primary" style="margin-right: 5px">Search</button>
                                        <a href="<?php echo e(url('/admin/users')); ?>" class="input-group-text text-white btn btn-danger">Clear</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="col-md-10 m-auto">
                    <form method="GET" action="<?php echo e(url('/admin/users')); ?>" class="gobal-serch-form form-group mb-3">
                        <?php echo csrf_field(); ?>
                        <div class="row" style="width: 100%">
                            <div class="col-md-5 mb-2">
                                <div class="d-flex align-items-center">
                                    <span class="input-group-text bg-gradient-blues" style="background-color: black; color: white">From</span>
                                    <input type="date" class="form-control" name="from" placeholder="From date" aria-label="Username" style="padding: 18px;">
                                </div>
                            </div>
                            <div class="col-md-5 mb-2">
                                <div class="d-flex align-items-center">
                                    <span class="input-group-text bg-gradient-burning" style="background-color: black; color: white">To</span>
                                    <input type="date" class="form-control" name="to" placeholder="To date" aria-label="Server" style="padding: 18px;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="d-flex align-items-center">
                                    <button type="submit" class="input-group-text text-white btn btn-primary" style="margin-right: 5px">Search</button>
                                    <a href="<?php echo e(url('/admin/users')); ?>" class="input-group-text text-white btn btn-danger">Clear</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-12">
                    <div class="table-responsive-scroll">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Total Tips</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $userTips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->index+1); ?></th>
                                    <td>
                                        <?php if($user[0]->user->avatar != null): ?>
                                            <img src="<?php echo e(asset('user/'.$user[0]->user->avatar)); ?>" height="30" width="30" style="border-radius: 50%"/>
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('backend/img/user-avater.png')); ?>" height="30" width="30" style="border-radius: 50%"/>
                                        <?php endif; ?><?php echo e($user[0]->user->name); ?>

                                    </td>
                                    <td><?php echo e($user[0]->user->email); ?></td>
                                    <td><?php echo e($user[0]->user->phone); ?></td>
                                    <td><?php echo e($user[0]->where('user_id', $user[0]->user->id)->sum('tips_amount')); ?> Tk.</td>
                                    <td>
                                        <?php if($user[0]->user->status == 1): ?>
                                            <a href="<?php echo e(url('/admin/active/'.$user[0]->user_id)); ?>" class="btn btn-sm btn-success">Active</a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('/admin/inactive/'.$user[0]->user_id)); ?>" class="btn btn-sm btn-warning">Inactive</a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(url('/admin/tip/'.$user[0]->user_id)); ?>" class="btn btn-sm btn-danger">Tips</a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/backend/auth/user/index.blade.php ENDPATH**/ ?>