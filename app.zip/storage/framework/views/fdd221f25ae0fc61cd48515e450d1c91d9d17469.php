

<?php $__env->startSection('title'); ?>
    User list
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-0">
        <div class="card">
            <div class="card-header">
                <h2>Members list</h2>
            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($loop->index+1); ?></th>
                                <td>
                                    <img src="<?php echo e(asset('users/'.$user->avatar)); ?>" height="30" width="30" style="border-radius: 50%"/><?php echo e($user->name); ?>

                                </td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td>
                                    <?php if($user->status == 1): ?>
                                        <a href="<?php echo e(url('/admin/active/'.$user->id)); ?>" class="btn btn-sm btn-success">Active</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/admin/inactive/'.$user->id)); ?>" class="btn btn-sm btn-warning">Inactive</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('/admin/delete/'.$user->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tererded24\resources\views/backend/auth/user/index.blade.php ENDPATH**/ ?>