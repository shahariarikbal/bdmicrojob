

<?php $__env->startSection('title'); ?>
    Membership list
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
<style type="text/css">
    th{
        text-transform: capitalize;
    }
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-0">
        <div class="card">
            <div class="card-header">
            	<div class="row">
            		<div class="col-md-6">
                		<h2>Membership list</h2>            			
            		</div>
            		<div class="col-md-6 text-right">
                		<a href="<?php echo e(url('admin/membership/create')); ?>" class="btn btn-primary">Add</a>
            		</div>
            	</div>

            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">name</th>
                            <th scope="col">facilities</th>
                            <th scope="col">per month charge</th>
                            <th scope="col">per membership cost</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = App\Models\Membership::orderBy('id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($loop->index+1); ?></th>
                                <td><?php echo e($membership->name); ?></td>
                                <td>
                                    <ul>
                                        <?php $__currentLoopData = json_decode($membership->facilities); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($facility); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </td>
                                <td><?php echo e($membership->per_month_charge); ?></td>
                                <td><?php echo e($membership->per_video_cost); ?></td>
                                <td>
    

                                    <a href="<?php echo e(url('admin/membership/edit' , $membership->id)); ?>" class="btn btn-sm btn-success">Edit</a>
                                    <form action="<?php echo e(url('admin/membership/delete', $membership->id)); ?>" method="post" class="d-inline" onsubmit="return confirm('Are you sure?')" id="delete<?php echo e($membership->id); ?>">

                                    	<?php echo csrf_field(); ?>


                                    	<button type="submit" class="btn btn-sm btn-danger">Delete</button>

                                	</form>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bdmicrojob\resources\views/backend/membership/index.blade.php ENDPATH**/ ?>