

<?php $__env->startSection('title'); ?>
    Category list
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-0">
        <div class="card">
            <div class="card-header">
            	<div class="row">
            		<div class="col-md-6">
                		<h2>Category list</h2>
            		</div>
            		<div class="col-md-6 text-right">
                		<a href="<?php echo e(url('admin/category/create')); ?>" class="btn btn-primary">Add</a>
            		</div>
            	</div>

            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Estimated Commission</th>
                            <th scope="col">Each Worker Earning</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($loop->index+1); ?></th>
                                <td><?php echo e($category->name); ?></td>
                                <td><?php echo e($category->price); ?>%</td>
                                <td><?php echo e($category->worker_earning); ?>tk</td>
                                <td>
                                    <?php if($category->status == 1): ?>
                                    <a href="#" class="btn btn-sm btn-success">Active</a>
                                    <?php else: ?>
                                    <a href="#" class="btn btn-sm btn-warning">Inactive</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($category->status==true): ?>
                                    <a href="<?php echo e(url('admin/category/inactive' , $category->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Inactivate</a>
                                    <?php elseif($category->status==false): ?>
                                    <a href="<?php echo e(url('admin/category/active' , $category->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-success">Activate</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('admin/category/edit' , $category->id)); ?>" class="btn btn-sm btn-success">Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BDMicrojobV2\bdmicrojob\resources\views/backend/category/show-category.blade.php ENDPATH**/ ?>