

<?php $__env->startSection('title'); ?>
	Job Post Success
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="job-details-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-10 m-auto">
                    <h1>Job is created successfully. Please wait for admin approval</h1>
                    <h3>Per Worker Earn: <?php echo e($per_worker_earn); ?>tk</h3>
                    <h3>Job Cost: <?php echo e($job_cost); ?>tk</h3>
                    <h3>Job Commission: <?php echo e($job_commission); ?>tk (<?php echo e($admin_commission); ?>%)</h3>
                    <h3>Total Cost: <?php echo e($postPriceEarnPrice); ?>tk</h3>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BDMicrojobV2\bdmicrojob\resources\views/frontend/auth/user/job/job-post-success.blade.php ENDPATH**/ ?>