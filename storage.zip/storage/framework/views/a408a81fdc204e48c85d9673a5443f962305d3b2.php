

<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-css'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>


<div class="container-fluid pb-0">














    <div class="video-block section-padding">
       <div class="row">
          <div class="col-xl-4 col-sm-6 mb-4">
             <div class="custom-card-one">
                <div class="row">
                   <div class="col-md-4">
                    <img src="<?php echo e(asset('backend/')); ?>/img/Vector.png" style="height: 50px; margin-top: 25px; margin-left: 15px;"/>
                   </div>
                   <div class="col-md-8">
                    <p class="earn-box-one">Approved Jobs</p>
                    <p class="earn-box-one"><?php echo e($approved_job_count); ?></p>
                   </div>
               </div>
             </div>
          </div>
          <div class="col-xl-4 col-sm-6 mb-4">
            <div class="custom-card-one">
               <div class="row">
                  <div class="col-md-4">
                   <img src="<?php echo e(asset('backend/')); ?>/img/Vector.png" style="height: 50px; margin-top: 25px; margin-left: 15px;"/>
                  </div>
                  <div class="col-md-8">
                   <p class="earn-box-one">Pending Jobs</p>
                   <p class="earn-box-one"><?php echo e($pending_job_count); ?></p>
                  </div>
              </div>
            </div>
         </div>
          
          
          <div class="col-xl-4 col-sm-6 mb-4">
             <div class="custom-card-four">
                <div class="row">
                   <div class="col-md-4">
                    <img src="<?php echo e(asset('backend/')); ?>/img/Vector3.png" style="height: 50px; margin-top: 25px; margin-left: 15px;"/>
                   </div>
                   <div class="col-md-8">
                    <p class="earn-box-one">Total users</p>
                    <p class="earn-box-one"><?php echo e($user_count); ?></p>
                   </div>
               </div>
             </div>
          </div>
       </div>
    </div>

    <div class="card">
        <div class="card-header">
            <span style="font-size: 18px; font-weight: bold">Visitor's List</span>
        </div>
        <div class="card-body">
            <table class="table table-hover table-bordered">
                <tr>
                    <th>SL</th>
                    <th>Visit Date</th>
                    <th>IP</th>
                    <th>Browser</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e(date('d-M-Y', strtotime($visitor->created_at))); ?></td>
                        <td>
                            <a href="<?php echo e(url('/admin/visitor/view/'.$visitor->id)); ?>"><?php echo e($visitor->ip); ?></a>
                        </td>
                        <td><?php echo e($visitor->browser); ?></td>
                        <td>
                            <a href="<?php echo e(url('/admin/visitor/view/'.$visitor->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-eye"></i>
                            </a>



                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php echo e($visitors->links()); ?>

        </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BDMicrojobV2\bdmicrojob\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>