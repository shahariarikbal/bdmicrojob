

<?php $__env->startSection('title'); ?>
	Job Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="job-details-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-10 m-auto">
                    <div class="job-details-top">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="done-job-outer">
                                    <div class="done-job-left">
                                        <h5 class="title">DONE</h5>
                                        <h3 class="number"><?php echo e($totalPostSubmit); ?> of <?php echo e($postDetail->worker_number); ?></h3>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" style="width: <?php echo e($totalPostSubmit); ?>%" aria-valuenow="<?php echo e($totalPostSubmit); ?>" aria-valuemin="0" aria-valuemax="<?php echo e($postDetail->worker_number); ?>"></div>
                                        </div>
                                    </div>
                                    <div class="done-job-right">
                                        <span class="icon-outer">
                                            <i class="fas fa-check-circle"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="earn-money-outer">
                                    <h3>
                                        YOU CAN EARN <strong>৳ <?php echo e($postDetail->category->worker_earning); ?></strong>
                                    </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(!$isPostSubmit && ($totalPostSubmit<$postDetail->worker_number)): ?>
                        <div class="job-details-form-item">
                            <div class="job-details-form-top">
                                <div class="left">
                                    <h4 class="title">
                                        <?php echo e($postDetail->title); ?>

                                    </h4>
                                </div>
                                <div class="right">
                                    <a href="<?php echo e(url('/dashboard')); ?>" class="hide-btn-inner">Hide</a>
                                </div>
                            </div>
                            <img src="<?php echo e(asset('/thumbnail/'.$postDetail->avatar)); ?>" alt="image" class="top-image">
                            <h4 class="job-details-text-title">
                                <i class="fas fa-list"></i>
                                What is expected from workers?
                            </h4>
                            <?php $__currentLoopData = $postDetail->specificTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="job-details-text-outer" style="background:#e3e3e3;padding: 10px;border-radius:5px; margin-top: 10px;">
                                    <p class="job-details-text">
                                        <?php echo e($task->specific_task); ?>

                                    </p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="report-btn-outer">
                                <a href="<?php echo e(url('/job/report/'.$postDetail->id)); ?>" class="report-btn-inner">Report</a>
                            </div>
                        </div>
                        <div class="job-details-form-item">
                            <h4 class="job-details-text-title">
                                REQUIRED PROOF THAT TASK WAS FINISHED?
                            </h4>
                            <p class="job-details-text">
                                1. <?php echo e($postDetail->required_task); ?>

                            </p>
                        </div>
                        <form action="<?php echo e(url('/post/submit/'.$postDetail->id)); ?>" method="post" class="job-details-form form-group" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="job-details-form-item">
                                <h4 class="job-details-text-title">
                                    Submit required work Prove
                                </h4>
                                <textarea name="work_prove" rows="5" cols="50" class="form-control"></textarea>
                            </div>
                            <div class="job-details-form-item">
                                <h4 class="job-details-text-title">
                                    UPLOAD SCREENSHOT PROVE
                                </h4>
                                <?php for($i = 1; $i<=$postDetail->required_screenshot; $i++): ?>
                                <label for="images[]">Screenshot <?php echo e($i); ?></label>
                                <input type="file" name="images[]" multiple class="form-control" required>
                                <?php endfor; ?>
                                
                            </div>
                            <button type="submit" class="job-details-form-sub-btn">Submit</button>
                        </form>
                        <?php elseif($totalPostSubmit>=$postDetail->worker_number): ?>
                        <div class="alert alert-danger">Job limit is finished!</div>
                        <?php else: ?>
                        <div class="alert alert-success">You already done this job</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BDMicrojobV2\bdmicrojob\resources\views/frontend/auth/user/job/job-details.blade.php ENDPATH**/ ?>