<ul class="sidebar navbar-nav<?php echo e(Route::is('dashboard') ? 'toggled' : ''); ?>">
    <li class="nav-item <?php echo e(Request::url() == url('admin/dashboard') ? 'active' : ''); ?>">
       <a class="nav-link" href="<?php echo e(url('/admin/dashboard')); ?>">
       <i class="fas fa-fw fa-home"></i>
       <span>Home</span>
       </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/categories') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/categories')); ?>">
        <i class="fa fa-tasks"></i>
        <span>Categories</span>
        </a>
     </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/jobs') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/jobs')); ?>">
        <i class="fa fa-tasks"></i>
        <span>All Jobs</span>
        </a>
     </li>
     <li class="nav-item <?php echo e(Request::url() == url('admin/pending/jobs') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/pending/jobs')); ?>">
        <i class="fa fa-tasks"></i>
        <span>Pending Jobs</span>
        </a>
     </li>
     
    <li class="nav-item <?php echo e(Request::url() == url('admin/users') ? 'active' : ''); ?> ">
       <a class="nav-link" href="<?php echo e(url('/admin/users')); ?>">
          <i class="fas fa-solid fa-dollar-sign"></i>
       <span>Users</span>
       </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/inactive/users/list') ? 'active' : ''); ?> ">
        <a class="nav-link" href="<?php echo e(url('/admin/inactive/users/list')); ?>">
           <i class="fas fa-solid fa-dollar-sign"></i>
        <span>InActive Users</span>
        </a>
     </li>
    
    
    <li class="nav-item <?php echo e(Request::url() == url('admin/deposit/request') ? 'active' : ''); ?>">
       <a class="nav-link" href="<?php echo e(url('admin/deposit/request')); ?>">
        <i class="fas fa-money-bill"></i>
       <span>Deposit Requests</span>
       </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/withdraw/request') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/withdraw/request')); ?>">
         <i class="fas fa-money-bill"></i>
        <span>Withdraw Requests</span>
        </a>
     </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/nid_verification/request') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('admin/nid_verification/request')); ?>">
         <i class="fas fa-money-bill"></i>
        <span>NID Verification</span>
        </a>
     </li>
     <li class="nav-item <?php echo e(Request::url() == url('admin/contacts') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/contacts')); ?>">
         <i class="fas fa-money-bill"></i>
        <span>Contacts</span>
        </a>
     </li>
    
     <li class="nav-item <?php echo e(Request::url() == url('admin/homepage') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/homepage')); ?>">
         <i class="fas fa-cog"></i>
        <span>Home Page</span>
        </a>
     </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/faqs') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/faqs')); ?>">
            <i class="fas fa-cog"></i>
            <span>FAQ</span>
        </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/about-us') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/about-us')); ?>">
            <i class="fas fa-cog"></i>
            <span>About Us</span>
        </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/term-condition') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/term-condition')); ?>">
            <i class="fas fa-cog"></i>
            <span>Terms & Conditions</span>
        </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/privacy-policy') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/privacy-policy')); ?>">
            <i class="fas fa-cog"></i>
            <span>Privacy Policy</span>
        </a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/marque-text') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/marque-text')); ?>">
         <i class="fas fa-cog"></i>
        <span>Marquee Text</span>
        </a>
     </li>
    <li class="nav-item <?php echo e(Request::url() == url('admin/settings') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin/settings')); ?>">
         <i class="fas fa-cog"></i>
        <span>Settings</span>
        </a>
     </li>
 </ul>
<?php /**PATH C:\xampp\htdocs\BDMicrojobV2\bdmicrojob\resources\views/backend/includes/sidebar.blade.php ENDPATH**/ ?>