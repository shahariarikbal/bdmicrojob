<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Askbootstrap" />
        <meta name="author" content="Askbootstrap" />
        <title><?php echo $__env->yieldContent('title', 'Admin'); ?></title>

        <link rel="icon" type="image/png" href="<?php echo e(asset('backend')); ?>/img/favicon.png" />

        <?php echo $__env->make('backend.includes.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldPushContent('page-css'); ?>
    </head>
    <body id="page-top">


        <?php echo $__env->make('backend.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




		<div id="wrapper">


        	<?php echo $__env->make('backend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div id="content-wrapper">

	        	<?php echo $__env->yieldContent('content'); ?>

	        	
			</div>
		</div>





        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>





        <?php echo $__env->make('backend.includes.logout-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <?php echo $__env->make('backend.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldPushContent('page-scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMicrojobV2\bdmicrojob\resources\views/backend/master.blade.php ENDPATH**/ ?>