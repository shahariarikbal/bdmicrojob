<link rel="shortcut icon" href="{{ asset('/frontend') }}/assets/images/favicon.jpg" type="image/x-icon">
<!-- Boostrap-5 CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<!-- google Fonts Link -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,800;1,900&display=swap" rel="stylesheet">
<!-- Fontawesome Link -->
<link rel="stylesheet" type="text/css" href="{{ asset('/frontend/') }}/assets/font/fontawesome/css/all.css">
<!-- owl-cerousel css link -->
<link rel="stylesheet" type="text/css" href="{{ asset('/frontend/') }}/assets/plugins/owl-carousel/owl.carousel.min.css">



{{-- toastr --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />


<!-- Main css Link -->
<link rel="stylesheet" type="text/css" href="{{ asset('/frontend/') }}/assets/css/style.css">
